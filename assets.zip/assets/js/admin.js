function check_docdelete(){
    return confirm('Are You Sure You Want Delete This Doctor');
}
function check_departdelete(){
    return confirm('Are You Sure You Want Delete This Department');
}
function check_appointdelete(){
    return confirm('Are You Sure You Want Delete This Appointment');
}
function check_patdelete(){
    return confirm('Are You Sure You Want Delete This Patient');
}